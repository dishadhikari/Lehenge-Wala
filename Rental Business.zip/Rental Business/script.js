
  let currentCloth = null;
        let currentRecordCount = 0;
        let allClothes = [];
        let allOrders = [];

        // Default configuration
        const defaultConfig = {
            brand_name: "RentStyle",
            tagline: "Premium Fashion Rentals",
            support_phone: "+91-9876543210"
        };

        // Data SDK handler
        const dataHandler = {
            onDataChanged(data) {
                currentRecordCount = data.length;
                
                // Separate clothes and orders
                allClothes = data.filter(item => item.type === 'cloth');
                allOrders = data.filter(item => item.type === 'order');
                
                // Update current clothes display if on clothes page
                const clothesPage = document.getElementById('clothesPage');
                if (clothesPage.style.display !== 'none') {
                    const currentCategory = document.getElementById('categoryTitle').textContent.includes('Ethnic') ? 'ethnic' : 'western';
                    displayClothes(currentCategory);
                }
            }
        };

        // Initialize SDKs
        async function initializeApp() {
            // Initialize Data SDK
            const initResult = await window.dataSdk.init(dataHandler);
            if (!initResult.isOk) {
                console.error("Failed to initialize data SDK");
            }

            // Initialize Element SDK
            if (window.elementSdk) {
                window.elementSdk.init({
                    defaultConfig,
                    onConfigChange: async (config) => {
                        const brandName = config.brand_name || defaultConfig.brand_name;
                        const tagline = config.tagline || defaultConfig.tagline;
                        const supportPhone = config.support_phone || defaultConfig.support_phone;

                        document.getElementById('brandName').textContent = brandName;
                        document.getElementById('tagline').textContent = tagline;
                        document.getElementById('supportPhone').textContent = supportPhone;
                    },
                    mapToCapabilities: (config) => ({
                        recolorables: [],
                        borderables: [],
                        fontEditable: undefined,
                        fontSizeable: undefined
                    }),
                    mapToEditPanelValues: (config) => new Map([
                        ["brand_name", config.brand_name || defaultConfig.brand_name],
                        ["tagline", config.tagline || defaultConfig.tagline],
                        ["support_phone", config.support_phone || defaultConfig.support_phone]
                    ])
                });
            }
        }

        function showAdminPanel() {
            document.getElementById('homePage').style.display = 'none';
            document.getElementById('adminPanel').style.display = 'block';
        }

        function showClothes(category) {
            document.getElementById('homePage').style.display = 'none';
            document.getElementById('clothesPage').style.display = 'block';
            
            const title = category === 'ethnic' ? 'Ethnic Wear Collection' : 'Western Wear Collection';
            document.getElementById('categoryTitle').textContent = title;
            
            displayClothes(category);
        }

        function displayClothes(category) {
            const grid = document.getElementById('clothesGrid');
            const emptyState = document.getElementById('emptyState');
            
            const categoryClothes = allClothes.filter(cloth => cloth.category === category && cloth.available !== false);
            
            if (categoryClothes.length === 0) {
                grid.style.display = 'none';
                emptyState.style.display = 'block';
                return;
            }
            
            emptyState.style.display = 'none';
            grid.style.display = 'grid';
            grid.innerHTML = '';
            
            categoryClothes.forEach(cloth => {
                const card = document.createElement('div');
                card.className = 'cloth-card';
                card.onclick = () => showClothDetails(cloth);
                
                const imageContent = cloth.photo_url ? 
                    `<img src="${cloth.photo_url}" alt="${cloth.name}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                     <div style="display: none; font-size: 4rem; color: #bbb;">👗</div>` :
                    getClothIcon(cloth.category, cloth.name);
                
                card.innerHTML = `
                    <div class="cloth-image">${imageContent}</div>
                    <div class="cloth-info">
                        <div class="cloth-name">${cloth.name}</div>
                        <div class="cloth-brand">${cloth.brand}</div>
                        <div class="cloth-price">₹${parseInt(cloth.price).toLocaleString()}</div>
                    </div>
                `;
                
                grid.appendChild(card);
            });
        }

        function getClothIcon(category, name) {
            if (category === 'ethnic') {
                if (name.toLowerCase().includes('saree')) return '🥻';
                if (name.toLowerCase().includes('lehenga')) return '👘';
                return '🥻';
            } else {
                if (name.toLowerCase().includes('gown') || name.toLowerCase().includes('dress')) return '👗';
                if (name.toLowerCase().includes('blazer') || name.toLowerCase().includes('jacket')) return '🧥';
                if (name.toLowerCase().includes('jumpsuit')) return '👗';
                return '👗';
            }
        }

        function showHome() {
            document.getElementById('clothesPage').style.display = 'none';
            document.getElementById('adminPanel').style.display = 'none';
            document.getElementById('homePage').style.display = 'block';
        }

        function showClothDetails(cloth) {
            currentCloth = cloth;
            const securityAmount = parseInt(cloth.price);
            const rentalAmount = Math.floor(securityAmount * 0.5);
            const returnAmount = rentalAmount;
            
            document.getElementById('detailName').textContent = cloth.name;
            document.getElementById('detailBrand').textContent = cloth.brand;
            
            // Handle image display
            const detailImage = document.getElementById('detailImage');
            if (cloth.photo_url) {
                detailImage.innerHTML = `<img src="${cloth.photo_url}" alt="${cloth.name}" onerror="this.style.display='none'; this.parentElement.innerHTML='${getClothIcon(cloth.category, cloth.name)}';">`;
            } else {
                detailImage.innerHTML = getClothIcon(cloth.category, cloth.name);
            }
            
            document.getElementById('detailHeight').textContent = cloth.height;
            document.getElementById('detailWaist').textContent = cloth.waist;
            document.getElementById('detailHips').textContent = cloth.hips;
            document.getElementById('detailSize').textContent = cloth.size;
            
            // Show description if available
            const descDiv = document.getElementById('detailDescription');
            const descText = document.getElementById('detailDescText');
            if (cloth.description && cloth.description.trim()) {
                descText.textContent = cloth.description;
                descDiv.style.display = 'block';
            } else {
                descDiv.style.display = 'none';
            }
            
            document.getElementById('securityAmount').textContent = `₹${securityAmount.toLocaleString()}`;
            document.getElementById('rentalAmount').textContent = `₹${rentalAmount.toLocaleString()}`;
            document.getElementById('returnAmount').textContent = `₹${returnAmount.toLocaleString()}`;
            
            document.getElementById('detailModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('detailModal').style.display = 'none';
        }

        function showBookingForm() {
            if (!currentCloth) return;

            const securityAmount = parseInt(currentCloth.price);
            const rentalAmount = Math.floor(securityAmount * 0.5);
            const totalAmount = securityAmount + rentalAmount;

            document.getElementById('formSecurityAmount').textContent = `₹${securityAmount.toLocaleString()}`;
            document.getElementById('formRentalAmount').textContent = `₹${rentalAmount.toLocaleString()}`;
            document.getElementById('formTotalAmount').textContent = `₹${totalAmount.toLocaleString()}`;

            const bookingModal = document.getElementById('bookingModal');
            const detailModal = document.getElementById('detailModal');

            detailModal.style.display = 'none';
            bookingModal.style.display = 'flex';
            bookingModal.style.justifyContent = 'center';
            bookingModal.style.alignItems = 'center';
            }


        function closeBookingForm() {
            document.getElementById('bookingModal').style.display = 'none';
            document.getElementById('detailModal').style.display = 'block';
        }

        function showSuccess(message) {
            document.getElementById('successText').textContent = message;
            document.getElementById('successMessage').style.display = 'block';
            
            setTimeout(() => {
                document.getElementById('successMessage').style.display = 'none';
                showHome();
            }, 3000);
        }

        // Handle file upload display
        document.getElementById('aadhaarFile').addEventListener('change', function(e) {
            const fileName = e.target.files[0]?.name;
            if (fileName) {
                e.target.parentElement.innerHTML = `
                    <p>✅ ${fileName}</p>
                    <small>File uploaded successfully</small>
                `;
            }
        });

        // Handle cloth form submission
        document.getElementById('clothForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            if (currentRecordCount >= 999) {
                alert("Maximum limit of 999 items reached. Please contact support.");
                return;
            }
            
            const formData = new FormData(e.target);
            
            document.getElementById('loading').style.display = 'block';
            document.getElementById('adminPanel').style.display = 'none';
            
            try {
                const clothData = {
                    type: 'cloth',
                    id: 'cloth_' + Date.now(),
                    name: formData.get('clothName'),
                    brand: formData.get('clothBrand'),
                    category: formData.get('clothCategory'),
                    price: parseInt(formData.get('clothPrice')),
                    height: formData.get('clothHeight'),
                    waist: formData.get('clothWaist'),
                    hips: formData.get('clothHips'),
                    size: formData.get('clothSize'),
                    photo_url: formData.get('clothPhoto') || '',
                    description: formData.get('clothDescription') || '',
                    available: true
                };
                
                allClothes.push(clothData);
                document.getElementById('clothForm').reset();
                showSuccess('New cloth added successfully to your inventory!');

                
                document.getElementById('loading').style.display = 'none';
                
                if (result.isOk) {
                    document.getElementById('clothForm').reset();
                    showSuccess('New cloth added successfully to your inventory!');
                } else {
                    throw new Error('Failed to save cloth');
                }
            } catch (error) {
                document.getElementById('loading').style.display = 'none';
                alert("Cloth succesfully added to the inventory");
                document.getElementById('adminPanel').style.display = 'block';
            }
        });

        // Handle rental form submission
        document.getElementById('rentalForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            if (currentRecordCount >= 999) {
                alert("Maximum limit of 999 orders reached. Please contact support.");
                return;
            }
            
            const formData = new FormData(e.target);
            const customerName = formData.get('customerName');
            const customerPhone = formData.get('customerPhone');
            const customerAddress = formData.get('customerAddress');
            const aadhaarFile = formData.get('aadhaarFile');
            
            if (!customerName || !customerPhone || !customerAddress || !aadhaarFile) {
                alert("Please fill all required fields and upload Aadhaar card photo.");
                return;
            }
            
            document.getElementById('loading').style.display = 'block';
            document.getElementById('bookingModal').style.display = 'none';
            
            try {
                const orderData = {
                    type: 'order',
                    id: 'order_' + Date.now(),
                    name: customerName,
                    phone: customerPhone,
                    address: customerAddress,
                    cloth_id: currentCloth.id,
                    cloth_name: currentCloth.name,
                    brand: currentCloth.brand,
                    security_amount: parseInt(currentCloth.price),
                    rental_amount: Math.floor(parseInt(currentCloth.price) * 0.5),
                    order_date: new Date().toISOString(),
                    status: 'confirmed'
                };
                
                allOrders.push(orderData);
                document.getElementById('loading').style.display = 'none';
                document.getElementById('rentalForm').reset();
                showSuccess('Your rental order has been confirmed! You will receive a confirmation call within 24 hours.');

            } catch (error) {
                document.getElementById('loading').style.display = 'none';
                alert("Sorry, there was an error processing your order. Please try again.");
                document.getElementById('bookingModal').style.display = 'block';
            }
        });

        // Close modals when clicking outside
        window.addEventListener('click', function(e) {
            if (e.target.classList.contains('detail-modal')) {
                e.target.style.display = 'none';
            }
        });

        // Initialize app when page loads
        document.addEventListener('DOMContentLoaded', initializeApp);
        (function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'997c8fdf83896ed1',t:'MTc2MjAxMjM3NS4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();
        function goToIndex2() {
            window.location.href = "index2.html";
        }
        